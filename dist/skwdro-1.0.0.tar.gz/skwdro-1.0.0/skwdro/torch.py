from skwdro.wrap_problem import dualize_primal_loss

robustify = dualize_primal_loss
